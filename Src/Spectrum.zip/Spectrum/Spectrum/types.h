// integer types
#define uint8	unsigned char
#define int8	char
#define uint16	unsigned short
#define int16	short
#define uint32	unsigned long
#define int32	long
