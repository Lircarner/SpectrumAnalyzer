#ifndef __GRAPHICS_H
#define __GRAPHICS_H

#define BORDER 0
#define CX 128
#define CY 64
#define CYB (CY/8)
#define PIX 2
#define BORDERCOLOR RGB(64,150,120)

extern uint8_t screen[128*40/8]; // 97x35

extern void ClearScreen(void);
//void ClearLines(uint8_t from, uint8_t count);

void PutPixel(int8_t x, int8_t y, int8_t value);
void SetPixel(int8_t x, int8_t y);


uint8_t* SetCurrentFont(uint8_t* new_font);
uint8_t* GetCurrentFont(void);

uint8_t PutChar(uint8_t x, uint8_t y, char c);
uint8_t PutCharInv(uint8_t x, uint8_t y, char c);
uint8_t GetWidthChar(char c);
uint8_t PutText(uint8_t x, uint8_t y, const char* s);
uint8_t PutTextCenter(uint8_t x, uint8_t y, const char* s);
uint8_t GetWidthText(const char* s);
uint8_t PutTextP(uint8_t x, uint8_t y, const char* s);
uint8_t PutTextCenterP(uint8_t x, uint8_t y, const char* s);
void PutTextNl(uint8_t x, uint8_t y, uint8_t vstep, const char* s);
void PutTextNlP(uint8_t x, uint8_t y, uint8_t vstep, const char* s);
uint8_t GetWidthTextP(const char* s);
uint8_t PutULong(uint8_t x, uint8_t y, unsigned long data);
uint8_t PutULongCenter(uint8_t x, uint8_t y, unsigned long data);


void FastSetPixel(int8_t x, int8_t y);
void FastClrPixel(int8_t x, int8_t y);
void FastXorPixel(int8_t x, int8_t y);

void DrawXLine(uint8_t x1, uint8_t x2, uint8_t y);
void DrawXLineDotted(uint8_t x1, uint8_t x2, uint8_t y);
void DrawYLine(uint8_t x, uint8_t y1, uint8_t y2);
void DrawYLineDotted(uint8_t x, uint8_t y1, uint8_t y2);

void Border(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2);

void FillRect(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2);
void ClrRect(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2);
void XorRect(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2);

// graph
void MoveTo(int8_t x, int8_t y);
void NextPoint(int8_t y);


#endif
