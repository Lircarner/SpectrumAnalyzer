#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/signal.h>
#include <avr/sleep.h>
#include <avr/pgmspace.h>
#include <string.h>
#include <util/delay.h>
#include <avr/eeprom.h>
#include <stdio.h>

#include "defines.h"
#include "lph7653.h"
#include "graphics.h"

#include "f8x8.h"
//#include "f9x14.h"
//#include "f12x12.h"
//#include "f15x22.h"
#include "dig3x5.h"
#include "dig14x21.h"

#include "spectrum.h"
#include "comms.h"

// EEPROM addresses
#define EEPROM_RSSI_OFS		10
#define EEPROM_XTAL_FREQ	11

// EEPROM defaults
#define EEPROM_RSSI_DEF		190
#define EPROM_XTAL_F_DEF	27

uint8_t cal[256];
/*
uint16_t ttt = 0;

#define TTT 41
*/
int main(void)
{
	uint8_t data, cmd, reg, n1, n2, max, rssiOfs;
	uint16_t ms, i, j;

	hwInit();											// setup hardware, regs

	LcdInit();	
	SetCurrentFont(dig3x5);
	
//	Border(96-80-2, 0, 96, 31);
	DrawYLine(9,0,31);
	DrawYLine(96,0,31);
	DrawXLine(9,95,31);

	char s[5];
	for (i=0; i<=80; i+=10)
	{
		SetPixel(i+10, 32);
//		if (i!=80)
//			PutTextCenter(i+15, 19, itoa(i,s,10));
	}

	for (i=0; i<=30; i+=5)
	{
		SetPixel(8, i);
	}

//	delay_ms(200);
	UpdateLcd();
	UpdateLcd();



	for (i=0; i<256; i++)
		cal[i] = 20;									// init cal values

	rssiOfs = eepromRead(EEPROM_RSSI_OFS);				// load cal from eeprom
	if (rssiOfs == 0xff) {
		rssiOfs = EEPROM_RSSI_DEF;
		eepromWrite(EEPROM_RSSI_OFS, rssiOfs);			// init eeprom
		eepromWrite(EEPROM_XTAL_FREQ, EPROM_XTAL_F_DEF);
	}

	{ // JDR

		cc2500Write(10,190);
		cc2500Write(11,127);
		cc2500Write(48,61);
		cc2500Write(11,12);
		cc2500Write(12,0);
		cc2500Write(13,88);
		cc2500Write(14,227);
		cc2500Write(15,142);
		cc2500Write(16,13);
		cc2500Write(17,47);
		cc2500Write(18,48);
		cc2500Write(19,35);
		cc2500Write(20,148);
		cc2500Write(10,0);
		cc2500Write(21,0);
		cc2500Write(33,86);
		cc2500Write(34,16);
		cc2500Write(24,24);
		cc2500Write(25,21);
		cc2500Write(26,108);
		cc2500Write(27,195);
		cc2500Write(29,145);
		cc2500Write(35,234);
		cc2500Write(38,17);
		cc2500Write(41,89);

		cc2500Write(44,143);
		cc2500Write(45,33);
		cc2500Write(46,11);
		cc2500Write(0,11);
		cc2500Write(2,12);
		cc2500Write(7,4);
		cc2500Write(8,18);
		cc2500Write(9,0);
		cc2500Write(6,255);
		cc2500Write(23,15);
		cc2500Write(1,142);
		cc2500Write(49,61);
		cc2500Write(52,61);

		// Calibrate

		for (i=0; i<256; i++) 
		{
			cc2500Write(0x0a, i);			// set channel
			cc2500Write(0x36, 0x3d);		// idle mode
			cc2500Write(0x33, 0x3d);		// manual calibration
			waitUS(800);					// wait for cal
			cc2500Read(0x25, &data);
			cal[i] = data;					// save cal value
		}

	
		while (!dataAvail()) 
		{
			cc2500Write(0x0a, n1);				// set channel
			cc2500Write(0x31, 0x3d);			// calibrate and wait
			waitUS(800);
			cc2500Write(0x34, 0x3d);			// enable rx

			ClrRect(10,0,95,30);

			int16_t rssimax = -9999;
			int16_t fqmax = 0;

			for (i=0; i<=85; i++)
			{

				cc2500Write(0x0a, i+i+i);			// set channel
				cc2500Write(0x25, cal[i+i+i]);		// calibration value
				waitUS(300);					// settling time

				max = 0;
				for (j=0; j<=25*2; j++) {		// oversample - save maximum
					waitUS(10);
					cc2500Read(0xf4, &data);	// read RSSI
					data -= rssiOfs;			// apply offset
					if (data > max)				// oversample and keep maximum
						max = data;
				}

				int16_t rssi = max+rssiOfs;
				if (rssi>=128)
					rssi = (rssi-256)/2-70;
				else
					rssi = (rssi)/2-70;
/*
				if(i==0)
				{
						PutText(0,0,itoa(rssi,s,10));
						UpdateLcd();
				}
*/

				if (rssi>rssimax)
				{
					rssimax = rssi;
					fqmax = i;
				}

				if (rssi<-90)
					rssi = -90;
				else
				if (rssi>-30)
					rssi = -30;

				DrawYLine(i+10, (-rssi-30)/2,30);

			}

			PutTextP(2,0,PSTR("-"));
			PutText(0,5,itoa(-rssimax,s,10));

			PutTextP(0,16,PSTR("24"));
			if (fqmax<10)
			{
				s[0] = '0';
				itoa(fqmax,s+1,10);
				PutText(0,23,s);
			}
			else
				PutText(0,23,itoa(fqmax,s,10));

			UpdateLcd();
		}

	}

	{ // JDR
		ClearScreen();
//		Border(0, 0, 96, 34);

		SetCurrentFont(f8x8);
		PutTextCenterP(48,13,PSTR("PC Mode"));

		UpdateLcd();
	}


//	DEBUG_PORT |= BIT(DEBUG2_BIT);						// led - power indicator

	while (1) {
		if (dataAvail()) {
			rcvByte(&data);
			if (data == SOH) {
//				DEBUG_PORT &= ~BIT(DEBUG2_BIT);			// blink led - activity

				while (!dataAvail())
					;
				rcvByte(&cmd);

				if (cmd == 'S') {						// get spectrum
					while(!dataAvail())
						;
					rcvByte(&n1);						// first channel

					while(!dataAvail())
						;
					rcvByte(&n2);						// last channel

					while(!dataAvail())
						;
					rcvByte(&data);						// delay between samples in 250 us increments (0=no delay)
					ms = data;

/*
					if (ttt==TTT)
					{
						PutTextP(80,0,PSTR("S"));
						PutText(0,0,itoa(n1,s,10));
						PutText(0,10,itoa(n2,s,10));
						PutText(0,20,itoa(ms,s,10));
						UpdateLcd();
					}
					ttt++;
*/
					cc2500Write(0x0a, n1);				// set channel
					cc2500Write(0x31, 0x3d);			// calibrate and wait
					waitUS(800);
					cc2500Write(0x34, 0x3d);			// enable rx

					for (i=n1; i<=n2; i++) {
						cc2500Write(0x0a, i);			// set channel
						cc2500Write(0x25, cal[i]);		// calibration value
						waitUS(300);					// settling time

						max = 0;
						for (j=0; j<=25*ms; j++) {		// oversample - save maximum
							waitUS(10);
							cc2500Read(0xf4, &data);	// read RSSI
							data -= rssiOfs;			// apply offset
							if (data > max)				// oversample and keep maximum
								max = data;
						}
						sendByte(max);					// send to host as we acquire
					}
				}

				if (cmd == 'R') {						// register read
					while(!dataAvail())
						;
					rcvByte(&reg);						// register to read

					cc2500Read(reg, &data);				// get data

					sendByte(data);
/*
					if (ttt==TTT)
					{
						PutTextP(80,0,PSTR("R"));
						PutText(0,0,itoa(reg,s,10));
						PutText(0,10,itoa(data,s,10));
						UpdateLcd();
					}
					ttt++;
*/
				}

				if (cmd == 'W') {						// register write
					while(!dataAvail())
						;
					rcvByte(&reg);						// register to read

					while(!dataAvail())
						;
					rcvByte(&data);						// data to write

					cc2500Write(reg, data);				// write it

					sendByte('A');						// ack
/*
					if (ttt==TTT)
					{
						PutTextP(80,0,PSTR("W"));
						PutText(0,0,itoa(reg,s,10));
						PutText(0,10,itoa(data,s,10));
						UpdateLcd();
					}
					ttt++;
*/
				}

				if (cmd == 'C') {						// calibrate
					for (i=0; i<256; i++) {
						cc2500Write(0x0a, i);			// set channel
						cc2500Write(0x36, 0x3d);		// idle mode
						cc2500Write(0x33, 0x3d);		// manual calibration
						waitUS(800);					// wait for cal
						cc2500Read(0x25, &data);
						cal[i] = data;					// save cal value
					}

					sendByte('A');						// ack
/*
					if (ttt==TTT)
					{
						PutTextP(80,0,PSTR("C"));
						UpdateLcd();
					}
					ttt++;
*/
				}

				if (cmd == 'r') {						// eeprom read
					while(!dataAvail())
						;
					rcvByte(&reg);						// eeprom address

					data = eepromRead(reg);				// do read

					sendByte(data);
/*
					if (ttt==TTT)
					{
						PutTextP(80,0,PSTR("r"));
						PutText(0,0,itoa(reg,s,10));
						PutText(0,10,itoa(data,s,10));
						UpdateLcd();
					}
					ttt++;
*/
				}

				if (cmd == 'w') {						// eeprom write
					while(!dataAvail())
						;
					rcvByte(&reg);						// eeprom address

					while(!dataAvail())
						;
					rcvByte(&data);						// eeprom data

					eepromWrite(reg, data);				// do write

					sendByte('A');						// ack

/*				
					if (ttt==TTT)
					{
						PutTextP(80,0,PSTR("w"));
						PutText(0,0,itoa(reg,s,10));
						PutText(0,10,itoa(data,s,10));
						UpdateLcd();
					}
					ttt++;
*/
				}
			}
		}
//		DEBUG_PORT |= BIT(DEBUG2_BIT);					// turn on led
	}

		
    return(0);
}

    