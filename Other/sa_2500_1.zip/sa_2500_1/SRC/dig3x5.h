/*
    created with FontEditor written by H. Reddmann
    HaReddmann at t-online dot de

    File Name           : dig3x5.h
    Date                : 29.03.2007
    Font size in bytes  : 0x002E, 46
    Font width          : 8
    Font height         : 5
    Font first char     : 0x2C
    Font last char      : 0x39
    Font bits per pixel : 1
    Font is compressed  : false

    The font data are defined as

    struct _FONT_ {
     // common shared fields
       uint16_t   font_Size_in_Bytes_over_all_included_Size_it_self;
       uint8_t    font_Width_in_Pixel_for_fixed_drawing;
       uint8_t    font_Height_in_Pixel_for_all_Characters;
       uint8_t    font_Bits_per_Pixels;
                    // if MSB are set then font is a compressed font
       uint8_t    font_First_Char;
       uint8_t    font_Last_Char;
       uint8_t    font_Char_Widths[font_Last_Char - font_First_Char +1];
                    // for each character the separate width in pixels,
                    // characters < 128 have an implicit virtual right empty row
                    // characters with font_Char_Widths[] == 0 are undefined

     // if compressed font then additional fields
       uint8_t    font_Byte_Padding;
                    // each Char in the table are aligned in size to this value
       uint8_t    font_RLE_Table[3];
                    // Run Length Encoding Table for compression
       uint8_t    font_Char_Size_in_Bytes[font_Last_Char - font_First_Char +1];
                    // for each char the size in (bytes / font_Byte_Padding) are stored,
                    // this get us the table to seek to the right beginning of each char
                    // in the font_data[].

     // for compressed and uncompressed fonts
       uint8_t    font_data[];
                    // bit field of all characters
    }
*/

#ifndef dig3x5_H
#define dig3x5_H

#include <inttypes.h>
#include <avr/pgmspace.h>

#define dig3x5_WIDTH 8
#define dig3x5_HEIGHT 5

uint8_t __ATTR_PROGMEM__ dig3x5[] = {
    0x00, 0x2E, 0x08, 0x05, 0x01, 0x2C, 0x39,
    0x07, 0x02, 0x01, 0x00, 0x03, 0x02, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 
    0x4C, 0x4A, 0x26, 0x25, 0x23, 0x04, 0xFE, 0xF8, 0xC5, 0xEF, 0xF5, 0xD6, 0xFA, 0x0F, 0xF9, 0xB7, 
    0xF6, 0x5F, 0x7B, 0x08, 0xFF, 0xD7, 0x7F, 0xEB, 0x07
};

#endif

