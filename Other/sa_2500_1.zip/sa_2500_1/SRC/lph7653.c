#include <inttypes.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <compat/ina90.h>
#include <stdlib.h>

#include "defines.h"
#include "lph7653.h"

#define DISP_DELAY 2

inline void I2CStart(void)
{

	_delay_loop_1(DISP_DELAY);

	clrbit(SDAPORT,SDABIT);

	_delay_loop_1(DISP_DELAY);

	clrbit(SCLPORT,SCLBIT);
	
	_delay_loop_1(DISP_DELAY);

}

inline void I2CStop(void)
{
	_delay_loop_1(DISP_DELAY);

	clrbit(SDAPORT,SDABIT);

	_delay_loop_1(DISP_DELAY);

	setbit(SCLPORT,SCLBIT);
	
	_delay_loop_1(DISP_DELAY);

	setbit(SDAPORT,SDABIT);

	_delay_loop_1(DISP_DELAY);
}

inline void I2CSendByte(uint8_t byte)
{
	uint8_t i;

	for (i=0; i<9; i++)
	{
		if (byte&128)
			setbit(SDAPORT,SDABIT);
		else
			clrbit(SDAPORT,SDABIT);

		byte <<= 1;
		byte |= 1;

		_delay_loop_1(DISP_DELAY);

		setbit(SCLPORT,SCLBIT);
		
		_delay_loop_1(DISP_DELAY);

		clrbit(SCLPORT,SCLBIT);

		_delay_loop_1(DISP_DELAY);

	}
}


void LcdInit(void)
{
	setbit(SCLDDR,SCLBIT);
	setbit(SDADDR,SDABIT);

	setbit(SCLPORT,SCLBIT);
	setbit(SDAPORT,SDABIT);

	delay_ms(100);

	I2CStart();
	I2CStop();

	delay_ms(100);

/*
	I2CStart();
	I2CSendByte(0x7A);
	I2CSendByte(0x61);
	I2CSendByte(0x00);


	I2CSendByte(0x01);
	I2CSendByte(0x02);
	I2CSendByte(0x04);
	I2CSendByte(0x08);
	I2CSendByte(0x10);
	I2CSendByte(0x20);
	I2CSendByte(0x40);

	I2CStop();
*/


}


void UpdateLcd(void)
{
	unsigned char *p = screen;
	unsigned char line, row;

	I2CStart();
	I2CSendByte(0x7A);
	I2CSendByte(0x60);
	I2CSendByte(0x00);

	for (line=0; line<5; line++)
	{
		for (row=0; row<97; row++)
		{
			I2CSendByte(*p++);
		}

		I2CSendByte(0);
		I2CSendByte(0);
		I2CSendByte(0);
		I2CSendByte(0);

		p += 31;
	}

	I2CStop();
}
