#include <inttypes.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <compat/ina90.h>


#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "graphics.h"
#include "fonts.h"



uint8_t screen[128*40/8]; // 97x35
uint8_t* current_font = 0;
uint8_t x_cur, y_cur;

void ClearScreen(void)
{
	memset(screen, 0, 640);
}
/*
void ClearLines(uint8_t from, uint8_t count)
{
	memset(screen+(uint16_t)(from)*16, 0, (uint16_t)(count)*16);
}
*/
void PutPixel(int8_t x, int8_t y, int8_t value)
{

#ifndef WIN32
	x &= (CX-1);
	y &= (CY-1);
#endif

	uint8_t* p = screen + x + (((uint16_t)(y>>3))<<7);
	uint8_t byte = 1 << (y&7);
	
	switch(value)
	{
		case 0:
			*p &= (~byte); 
			break;
		case 1:
			*p |= byte; 
			break;
		case 2:
			*p ^= byte; 
			break;
	}
//#ifdef _DEBUG
//	Sleep(10);
//#endif
}

void SetPixel(int8_t x, int8_t y)
{
#ifndef WIN32
	x &= (CX-1);
	y &= (CY-1);
#endif
	uint8_t byte = 1 << (y&7);
	uint8_t* p = screen + x + (((uint16_t)(y>>3))<<7);
	*p |= byte; 
}

void ClrPixel(int8_t x, int8_t y)
{
#ifndef WIN32
	x &= (CX-1);
	y &= (CY-1);
#endif
	uint8_t byte = 1 << (y&7);
	uint8_t* p = screen + x + (((uint16_t)(y>>3))<<7);
	*p &= ~byte; 
}


uint8_t PutChar(uint8_t x, uint8_t y, char c)
{
//#ifdef WIN32
//	TRACE("Char:%c ", c);
//#endif

	uint8_t i, j, width, height;
	uint16_t t;
	const prog_uchar *p;
	uint8_t* font_in_use = current_font;


#ifdef _DEBUG
	if ( ((uint8_t)c < pgm_read_byte(current_font+5)) ||
		((uint8_t)c > pgm_read_byte(current_font+6)) )
		font_in_use = f8x8;

#endif

	c -= pgm_read_byte(font_in_use+5); 
	width = pgm_read_byte(font_in_use+7+(uint8_t)c);
	height = pgm_read_byte(font_in_use+3);

	p = font_in_use+7+pgm_read_byte(font_in_use+6) - pgm_read_byte(font_in_use+5)+1;

	if (height==8)
	{
		for (i=0; i<(uint8_t)c; i++)
			p += pgm_read_byte(font_in_use+7+i);

//	#ifdef WIN32
//		TRACE("(w=%i)\n", width);
//	#endif
		for (i=0; i<width; i++)
		{
			c = pgm_read_byte(p++);

			for (j=0; j<8; j++)
			{
				PutPixel(x,y+j,(c>>j)&1);
//	#ifdef WIN32
//				if ((c>>j)&1)
//					TRACE("*");
//				else
//					TRACE(".");
//	#endif
			}
			x++;
//	#ifdef WIN32
//		TRACE("\n");
//	#endif
		}

		for (j=0; j<8; j++)
		{
			PutPixel(x, y+j, 0);
		}

		return width+1;
	}

	t = 0;
	for (i=0; i<(uint8_t)c; i++)
		t += pgm_read_byte(font_in_use+7+i);

	int t1 = t*height/8;
	int t2 = t*height%8;

	p+=t1;

//	#ifdef WIN32
//		TRACE("(w=%i)\n", width);
//	#endif
	c = pgm_read_byte(p++);

	for (i=0; i<width; i++)
		{

			for (j=0; j<height; j++)
			{
				PutPixel(x,y+j,(c>>t2)&1);
//	#ifdef WIN32
//				if ((c>>t2)&1)
//					TRACE("*");
//				else
//					TRACE(".");
//	#endif
				t2++;
				t2 %= 8;
				if (t2==0)
				{
					t1++;
					c = pgm_read_byte(p++);
				}
			}
			x++;
//	#ifdef WIN32
//		TRACE("\n");
//	#endif
		}

		for (j=0; j<height; j++)
		{
			PutPixel(x, y+j, 0);
		}
		return width+1;
}

uint8_t PutCharInv(uint8_t x, uint8_t y, char c)
{
//#ifdef WIN32
//	TRACE("Char:%c ", c);
//#endif

	uint8_t i, j, width, height;
	uint16_t t;
	const prog_uchar *p;
	uint8_t* font_in_use = current_font;


#ifdef _DEBUG
	if ( ((uint8_t)c < pgm_read_byte(current_font+5)) ||
		((uint8_t)c > pgm_read_byte(current_font+6)) )
		font_in_use = f8x8;

#endif

	c -= pgm_read_byte(font_in_use+5); 
	width = pgm_read_byte(font_in_use+7+(uint8_t)c);
	height = pgm_read_byte(font_in_use+3);

	p = font_in_use+7+pgm_read_byte(font_in_use+6) - pgm_read_byte(font_in_use+5)+1;

	if (height==8)
	{
		for (i=0; i<(uint8_t)c; i++)
			p += pgm_read_byte(font_in_use+7+i);

//	#ifdef WIN32
//		TRACE("(w=%i)\n", width);
//	#endif

		PutPixel(x, y-1, 1);
		for (j=0; j<8; j++)
		{
			PutPixel(x, y+j, 1);
		}

		x++;

		for (i=0; i<width; i++)
		{
			PutPixel(x, y-1, 1);

			c = pgm_read_byte(p++);

			for (j=0; j<8; j++)
			{
				PutPixel(x,y+j,((c>>j)&1)^1);
//	#ifdef WIN32
//				if ((c>>j)&1)
//					TRACE("*");
//				else
//					TRACE(".");
//	#endif
			}
			x++;
//	#ifdef WIN32
//		TRACE("\n");
//	#endif
		}

		PutPixel(x, y-1, 1);
		for (j=0; j<8; j++)
		{
			PutPixel(x, y+j, 1);
		}

		return width+2;
	}

	t = 0;
	for (i=0; i<(uint8_t)c; i++)
		t += pgm_read_byte(font_in_use+7+i);

	int t1 = t*height/8;
	int t2 = t*height%8;

	p+=t1;

//	#ifdef WIN32
//		TRACE("(w=%i)\n", width);
//	#endif
	c = pgm_read_byte(p++);

	PutPixel(x, y-1, 1);
	for (j=0; j<height; j++)
	{
		PutPixel(x, y+j, 1);
	}

	x++;

	for (i=0; i<width; i++)
		{
			PutPixel(x, y-1, 1);

			for (j=0; j<height; j++)
			{
				PutPixel(x,y+j,((c>>t2)&1)^1);
//	#ifdef WIN32
//				if ((c>>t2)&1)
//					TRACE("*");
//				else
//					TRACE(".");
//	#endif
				t2++;
				t2 %= 8;
				if (t2==0)
				{
					t1++;
					c = pgm_read_byte(p++);
				}
			}
			x++;
//	#ifdef WIN32
//		TRACE("\n");
//	#endif
		}

		PutPixel(x, y-1, 1);
		for (j=0; j<height; j++)
		{
			PutPixel(x, y+j, 1);
		}
		return width+2;
}

uint8_t GetWidthChar(char c)
{
	uint8_t i, j, width, height;
	uint16_t t;
//	const prog_uchar *p;
	uint8_t* font_in_use = current_font;

#ifdef _DEBUG
	if ( ((uint8_t)c < pgm_read_byte(current_font+5)) ||
		((uint8_t)c > pgm_read_byte(current_font+6)) )
		font_in_use = f8x8;

#endif

	c -= pgm_read_byte(font_in_use+5); 
	width = pgm_read_byte(font_in_use+7+(uint8_t)c);

	return width+1;
}

uint8_t PutText(uint8_t x, uint8_t y, const char* s)
{
	uint8_t width = 0;

	while(*s)
	{
		width += PutChar(x+width, y, *s++);
	}

	return width;
}

uint8_t PutTextCenter(uint8_t x, uint8_t y, const char* s)
{
		uint8_t width = GetWidthText(s);
		return PutText(x-(width>>1),y,s);
}

uint8_t GetWidthText(const char* s)
{
	uint8_t width = 0;

	while(*s)
	{
		width += GetWidthChar(*s++);
	}

	return width;
}

uint8_t PutTextP(uint8_t x, uint8_t y, const char* s)
{
	uint8_t width = 0;

	while(pgm_read_byte(s))
	{
		width += PutChar(x+width, y, pgm_read_byte(s++));
	}

	return width;
}

uint8_t PutTextCenterP(uint8_t x, uint8_t y, const char* s)
{
		uint8_t width = GetWidthTextP(s);
		return PutTextP(x-(width>>1),y,s);
}

void PutTextNl(uint8_t x, uint8_t y, uint8_t vstep, const char* s)
{
	uint8_t width = 0;

	while(*s)
	{
		if (*s == '\n')
		{
			width = 0;
			y += vstep;
			s++;
		}
		else
			width += PutChar(x+width, y, *s++);
	}
}

void PutTextNlP(uint8_t x, uint8_t y, uint8_t vstep, const char* s)
{
	uint8_t width = 0;

	while(pgm_read_byte(s))
	{
		if (pgm_read_byte(s) == '\n')
		{
			width = 0;
			y += vstep;
			s++;
		}
		else
			width += PutChar(x+width, y, pgm_read_byte(s++));
	}
}

uint8_t GetWidthTextP(const char* s)
{
	uint8_t width = 0;

	while(pgm_read_byte(s))
	{
		width += GetWidthChar(pgm_read_byte(s++));
	}

	return width;
}

uint8_t* SetCurrentFont(uint8_t* new_font)
{
	uint8_t* tmp = current_font;
	current_font = new_font;

	return tmp;
}

uint8_t* GetCurrentFont(void)
{
	return current_font;
}

void DrawXLine(uint8_t x1, uint8_t x2, uint8_t y)
{	
	uint8_t x;
	if (x1>x2)
	{
		uint8_t t;
		t = x1;
		x1 = x2;
		x2 = t;
	}
	for (x=x1; x<=x2; x++)
		FastSetPixel(x,y);
}

void DrawXLineDotted(uint8_t x1, uint8_t x2, uint8_t y)
{
	uint8_t x;
	if (x1>x2)
	{
		uint8_t t;
		t = x1;
		x1 = x2;
		x2 = t;
	}
	for (x=x1; x<=x2; x+=2)
		FastSetPixel(x,y);
}

void DrawYLine(uint8_t x, uint8_t y1, uint8_t y2)
{
	uint8_t y;
	if (y1>y2)
	{
		uint8_t t;
		t = y1;
		y1 = y2;
		y2 = t;
	}
	for (y=y1; y<=y2; y++)
		FastSetPixel(x,y);
}

void DrawYLineDotted(uint8_t x, uint8_t y1, uint8_t y2)
{
	uint8_t y;
	if (y1>y2)
	{
		uint8_t t;
		t = y1;
		y1 = y2;
		y2 = t;
	}
	for (y=y1; y<=y2; y+=2)
		FastSetPixel(x,y);
}

void Border(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2)
{
	DrawXLine(x1,x2,y1);
	DrawXLine(x1,x2,y2);
	DrawYLine(x1,y1,y2);
	DrawYLine(x2,y1,y2);
}

void FillRect(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2)
{
	uint8_t x, y;
	for (x = x1; x<=x2; x++)
		for (y = y1; y<=y2; y++)
			FastSetPixel(x,y);
}

void ClrRect(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2)
{
	uint8_t x, y;
	for (x = x1; x<=x2; x++)
		for (y = y1; y<=y2; y++)
			FastClrPixel(x,y);
}

void XorRect(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2)
{
	uint8_t x, y;
	for (x = x1; x<=x2; x++)
		for (y = y1; y<=y2; y++)
			FastXorPixel(x,y);
}




uint8_t PutULong(uint8_t x, uint8_t y, unsigned long data)
{
	char s[11];
	ultoa(data, s, 10);
	
	return PutText(x,y,s);	
}

uint8_t PutULongCenter(uint8_t x, uint8_t y, unsigned long data)
{
	char s[11];
	ultoa(data, s, 10);
	
	return PutTextCenter(x,y,s);	
}

void FastSetPixel(int8_t x, int8_t y)
{
	*(screen + x + (((uint16_t)(y>>3))<<7)) |= (1 << (y&7));
}

void FastClrPixel(int8_t x, int8_t y)
{
	*(screen + x + (((uint16_t)(y>>3))<<7)) &= ~(1 << (y&7));
}

void FastXorPixel(int8_t x, int8_t y)
{
	*(screen + x + (((uint16_t)(y>>3))<<7)) ^= (1 << (y&7));
}

void MoveTo(int8_t x, int8_t y)
{
	x_cur = x, y_cur = y;
}

void NextPoint(int8_t y)
{
	int8_t t = (y_cur+y)/2;
	DrawYLine(x_cur, y_cur, t);
	x_cur++;
	y_cur = y;
	DrawYLine(x_cur, y_cur, t);
}

