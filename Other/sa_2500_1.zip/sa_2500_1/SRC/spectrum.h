//#include "types.h"

// commands
#define RESP_ACK		1
#define RESP_NAK		0
#define CMD_POLL		0x10
#define CMD_PIR			0x11

#define CMD_STATUS		0x14
#define CMD_SHDN		0x15
#define CMD_CONTROL		0x16
#define CMD_AUTO_SHDN	0x17

void cc2500Read(uint8_t reg, uint8_t* data);
void cc2500Write(uint8_t reg, uint8_t data);
void waitUS(uint16_t us);
void waitMS(uint16_t ms);
void hwInit(void);
void sendString(char* t);
unsigned char eepromRead( int location);
void eepromWrite( int location, unsigned char byte);
