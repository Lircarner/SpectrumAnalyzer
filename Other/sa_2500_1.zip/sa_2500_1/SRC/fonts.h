
#ifndef FONTS_H
#define FONTS_H

extern uint8_t __ATTR_PROGMEM__ dig3x5[];
extern uint8_t __ATTR_PROGMEM__ f8x8[];
extern uint8_t __ATTR_PROGMEM__ f12x12[];
extern uint8_t __ATTR_PROGMEM__ dig14x21[];

#endif FONTS_H
