#ifndef DISPLAY_H
#define DISPLAY_H

void LcdInit(void);

extern uint8_t screen[128*40/8]; // 97x35

void UpdateLcd(void);

#endif // DISPLAY_H
