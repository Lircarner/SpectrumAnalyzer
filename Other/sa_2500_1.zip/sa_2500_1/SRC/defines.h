#ifndef DEFINES_H
#define DEFINES_H



// Display I/O ports

#define SCLPORT PORTD
#define SCLDDR DDRD
#define SCLBIT 5

#define SDAPORT PORTB
#define SDADDR DDRB
#define SDABIT 0

// port bits
#define RF_PORT			PORTB
#define RF_CS_BIT		2
#define RF_MOSI_BIT		3
#define RF_MISO_BIT		4
#define RF_SCK_BIT 		5

//#define DEBUG_PORT		PORTD
//#define DEBUG1_BIT		2
//#define DEBUG2_BIT		3

#define PORTB_DDR		0x2f
#define PORTB_INIT		0x04
//#define PORTC_DDR		0xff
//#define PORTC_INIT		0x00
#define PORTD_DDR		0xfe
#define PORTD_INIT		0x03

#define BIT(x) (1<<(x))

// Stuff

#define setbit(x,y)(x|=(1<<y))
#define clrbit(x,y)(x&=~(1<<y))
#define cplbit(x,y)(x^=(1<<y))
#define getbit(x,y)((x&(1<<y)) ? 1:0)

#define delay_ms(delay) \
{ \
	uint16_t delay_ms_i; \
	for (delay_ms_i=0; delay_ms_i<delay; delay_ms_i++) \
		_delay_ms(1); \
} 

#endif // DEFINES_H
