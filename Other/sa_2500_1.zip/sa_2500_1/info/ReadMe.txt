2.4-2.485GHz Portable Spectrum Analyzer
	

Having found an article on the Internet about the Low-Cost 2.4-GHz Spectrum Analyzer (author – Scott Armitage), I wanted to make a similar spectrum analyzer, only in a portable version.

As a display, I assumed to use the Philips LPH7653 LCD (from some phones; these are sold on the radio market). This LCD displays a black and white image with a size of 97x35 pixels.

In addition to the spectrum graph, the frequency at which the signal level is maximum and this level itself (in dBm) is displayed on the screen. The frequency resolution is 1 MHz.

Of course, it is still possible to connect the analyzer to a computer.

Scheme

I used Atmel's ATMEGA8L microcontroller. To generate a voltage of -6 V (necessary for the LCD), a converter is installed on the LMC7660 microcircuit (ICL7660, etc.). The LCD backlight is not used. The switch (not shown in the diagram) allows you to power the analyzer from a Crown battery or from a computer's USB bus. The main part of the circuit is assembled on a breadboard, which also has a connector for connecting a programmer (PROG) and two submodules: a submodule of the CC2500 chip and a USB submodule.

(click to enlarge)

The submodule of the CC2500 microcircuit is a separate handkerchief made by the laser-iron method. The drawing of the board in Sprint Layout format is in the file at the bottom of the page. It turned out that it was not easy to find suitable inductors for the output phase shifter, so I performed a BALUN on a small ferrite "binoculars" by passing two pieces of winding wire twisted together into the holes. On the one hand, these wires are connected to the right terminals of the 100 pF capacitors according to the scheme, on the other – to the "ground" and to the antenna. I used an N-type socket as a connector.

(click to enlarge)
To connect the microcontroller to the computer via the USB bus, I used a ready-made module on an FT232BM chip. Only the TXD, RXD, and +5 V signals from the USB bus are used to power the microcontroller (+5 V is connected to one of the switch terminals).
(click to enlarge)
The device is assembled in a plastic housing Z-48 manufactured by Z.T.S. Maszczyk. The main breadboard and submodules are mounted on the lower part of the case. An N-type connector and a power switch are also attached there. The USB connector extends to the side wall. The LCD is connected with flexible wires and is pressed from the inside to the top of the case using a piece of foam rubber.

(click to enlarge)

The microcontroller program

The original code is mostly used, with the exception of the image output functions. The text of the program (for WinAVR) and the finished HEX file are in the file at the end of the page. I used AVRISP-MK2 to program the microcontroller. If desired, you can easily fix the p file.bat for working with another programmer.

Connecting to a computer

The original program LCSA.EXE it is designed for a CP2102 chip from Silicon Labs, and I used FT232BM from FTDI. It turned out that you only need to add one line to the Windows registry in order for the program to work.

File 1.reg:
-----------------
REGEDIT4
[HKEY_LOCAL_MACHINE\HARDWARE\DEVICEMAP\SERIALCOMM] “\\device\\slabser0″=”COM20”
————————————————-

You need to fix COM20 to the COM port number that appeared in the system when connecting the analyzer, and then run the 1.reg file.

08.06.2008